import tkinter as tk
from tkinter import ttk, messagebox
import threading
import time
import email.utils
import pyautogui
import sys
import os
import webbrowser
import requests
import zipfile
import shutil
# 导入更底层的win32api库以实现更高的点击速度
import win32api
import win32con
import win32gui
import win32process
import subprocess
# 优化pyautogui设置以减少延迟
pyautogui.PAUSE = 0  # 设置pyautogui操作间的延迟为0
pyautogui.FAILSAFE = False  # 禁用安全模式
from PIL import Image
import pystray
from pystray import MenuItem as item
from pynput import keyboard, mouse
from pynput.keyboard import Key, Listener
from pynput.mouse import Button, Listener as MouseListener

class MouseClicker:
    def __init__(self):
        self.is_running = False
        self.click_thread = None
        self.clicks_per_second = 10
        # 热键设置
        self.hotkey = Key.f9  # 默认热键为F9
        self.hotkey_type = "keyboard"  # 默认热键类型为键盘键
        self.hotkey_name = "F9"
        self.is_setting_hotkey = False
        self.is_setting_mouse_hotkey = False
        self.root = tk.Tk()
        self.root.title("芙芙鼠标连点器")
        self.root.geometry("450x500")
        self.root.resizable(False, False)
        
        # 创建点击类型变量（必须在root窗口之后创建）
        self.click_type = tk.StringVar(value="left")  # 默认左键点击
        
        # 设置天蓝色背景
        self.bg_color = "#87CEEB"
        self.root.configure(bg=self.bg_color)
        
        # 窗口居中
        self.root.update_idletasks()
        width, height = self.root.winfo_width(), self.root.winfo_height()
        x = (self.root.winfo_screenwidth() - width) // 2
        y = (self.root.winfo_screenheight() - height) // 2
        self.root.geometry(f'{width}x{height}+{x}+{y}')
        
        # 设置窗口图标
        self.root.iconbitmap('D:\\FMC\\FMC.ico')
        
        # 设置任务栏图标
        try:
            # 获取窗口句柄
            hwnd = win32gui.FindWindow(None, "芙芙鼠标连点器")
            if hwnd:
                # 加载图标
                icon_path = 'D:\\FMC\\FMC.ico'
                hicon = win32gui.LoadImage(
                    None,  # 模块句柄，None表示加载独立图标
                    icon_path,  # 图标路径
                    win32con.IMAGE_ICON,  # 资源类型
                    0, 0,  # 宽度和高度，0表示使用资源默认值
                    win32con.LR_LOADFROMFILE | win32con.LR_DEFAULTSIZE  # 加载选项
                )
                if hicon:
                    # 设置窗口图标
                    win32gui.SendMessage(hwnd, win32con.WM_SETICON, win32con.ICON_SMALL, hicon)  # 小图标
                    win32gui.SendMessage(hwnd, win32con.WM_SETICON, win32con.ICON_BIG, hicon)  # 大图标
        except Exception as e:
            pass  # 如果设置任务栏图标失败，不影响程序运行
        
        # 创建画布
        self.canvas = tk.Canvas(self.root, width=450, height=500, bg=self.bg_color, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        
        # 初始化组件
        self.create_widgets()
        self.setup_system_tray()
        self.setup_global_key_listener()
        
        # 窗口事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        # 使用wm_state来监听最小化事件，而不是替换内置的iconify方法
        self.root.bind("<Unmap>", lambda event: self.on_minimize() if self.root.state() == 'iconic' else None)
        
        # 检查更新
        threading.Thread(target=self.check_for_updates, daemon=True).start()
        
        # 保存用户关闭偏好
        self.close_preference = None  # None: 未设置, "minimize": 最小化, "close": 关闭
    
    # 移除了背景图片加载功能
    
    def create_widgets(self):
        """创建UI组件"""
        self.setup_styles()
        
        # 标题
        ttk.Label(self.canvas, text="芙芙鼠标连点器", font=('Microsoft YaHei', 20, 'bold')).place(x=100, y=30)
        
        # 状态显示
        status_frame = ttk.Frame(self.canvas)
        status_frame.place(x=35, y=80, width=380, height=80)
        self.status_label = ttk.Label(status_frame, text="状态: 已停止", font=('Microsoft YaHei', 15, 'bold'), foreground="#e74c3c")
        self.status_label.pack(fill="both", expand=True, padx=20, pady=10)
        
        # 点击类型选择（放在状态显示和频率调制之间）
        click_type_frame = ttk.Frame(self.canvas)
        click_type_frame.place(x=35, y=160, width=380, height=40)
        ttk.Label(click_type_frame, text="点击类型: ", font=('Microsoft YaHei', 12)).pack(side="left", padx=(20, 10), pady=5)
        ttk.Radiobutton(click_type_frame, text="左键点击", variable=self.click_type, value="left").pack(side="left", padx=(0, 20), pady=5)
        ttk.Radiobutton(click_type_frame, text="右键点击", variable=self.click_type, value="right").pack(side="left", pady=5)
        
        # 热键设置
        hotkey_frame = ttk.Frame(self.canvas)
        hotkey_frame.place(x=35, y=200, width=380, height=40)
        ttk.Label(hotkey_frame, text="开始/停止热键: ", font=('Microsoft YaHei', 12)).pack(side="left", padx=(20, 10), pady=5)
        self.hotkey_label = ttk.Label(hotkey_frame, text="F9", font=('Microsoft YaHei', 12, 'bold'), foreground="#4a90e2")
        self.hotkey_label.pack(side="left", padx=(0, 10), pady=5)
        self.set_hotkey_button = ttk.Button(hotkey_frame, text="设置热键", command=self.set_hotkey)
        self.set_hotkey_button.pack(side="left")
        
        # 控制面板
        control_frame = ttk.Frame(self.canvas)
        control_frame.place(x=35, y=250, width=380, height=150)
        
        # 滑块控件
        ttk.Label(control_frame, text="点击频率调整: ", font=('Microsoft YaHei', 14)).pack(anchor="w", padx=20, pady=(10, 5))
        self.click_rate_slider = ttk.Scale(control_frame, from_=1, to=5000, orient="horizontal", command=self.on_slider_change, length=320)
        self.click_rate_slider.set(self.clicks_per_second)
        self.click_rate_slider.pack(anchor="center", padx=20, pady=5)
        
        # 输入区域
        input_frame = ttk.Frame(control_frame)
        input_frame.pack(fill="x", padx=20, pady=5)
        ttk.Label(input_frame, text="自定义速度: ", font=('Microsoft YaHei', 12)).pack(side="left", padx=(0, 10))
        self.click_rate_input = ttk.Entry(input_frame, width=6, font=('Microsoft YaHei', 12))
        self.click_rate_input.insert(0, str(self.clicks_per_second))
        self.click_rate_input.pack(side="left", padx=(0, 10))
        ttk.Button(input_frame, text="应用", command=self.apply_click_rate).pack(side="left", padx=(0, 20))
        self.rate_label = ttk.Label(input_frame, text=f"当前: {self.clicks_per_second} 次/秒", font=('Microsoft YaHei', 12, 'bold'), foreground="#4a90e2")
        self.rate_label.pack(side="right")
        
        # 主按钮
        self.toggle_button = ttk.Button(self.canvas, text="按F9键开始/停止", command=self.toggle_clicking)
        self.toggle_button.place(x=100, y=400, width=250, height=50)
        
        # 连点器信息按钮
        self.info_button = ttk.Button(self.canvas, text="连点器信息", command=self.show_clicker_info)
        self.info_button.place(x=150, y=450, width=150, height=40)
    
    def on_slider_change(self, value):
        """滑块值变化时的回调函数"""
        self.clicks_per_second = int(float(value))
        if hasattr(self, 'rate_label'):
            self.rate_label.config(text=f"当前: {self.clicks_per_second} 次/秒")
        if hasattr(self, 'click_rate_input'):
            self.click_rate_input.delete(0, tk.END)
            self.click_rate_input.insert(0, str(self.clicks_per_second))
    
    def apply_click_rate(self):
        """应用输入的点击速度（每秒点击次数，最高5000次/秒）"""
        if not hasattr(self, 'click_rate_input'):
            return
        input_text = self.click_rate_input.get().strip()
        try:
            new_rate = int(input_text)
            if new_rate > 0:
                # 限制最高点击速度为每秒5000次
                self.clicks_per_second = min(5000, new_rate)
                if hasattr(self, 'click_rate_slider'):
                    self.click_rate_slider.set(self.clicks_per_second)
                if hasattr(self, 'rate_label'):
                    self.rate_label.config(text=f"当前: {self.clicks_per_second} 次/秒")
                # 如果输入值超过5000，更新输入框显示实际应用的值
                if new_rate > 5000:
                    self.click_rate_input.delete(0, tk.END)
                    self.click_rate_input.insert(0, str(self.clicks_per_second))
                self.click_rate_input.focus()
            else:
                messagebox.showerror("输入错误", "点击速度必须大于0")
                self.click_rate_input.delete(0, tk.END)
                self.click_rate_input.insert(0, str(self.clicks_per_second))
        except ValueError:
            messagebox.showerror("输入错误", "请输入有效的数字")
            self.click_rate_input.delete(0, tk.END)
            self.click_rate_input.insert(0, str(self.clicks_per_second))
    
    def setup_system_tray(self):
        """设置系统托盘"""
        try:
            # 使用指定的ICO文件作为系统托盘图标
            icon_path = r'D:\FMC\FMC.ico'
            
            # 检查文件是否存在
            if os.path.exists(icon_path):
                try:
                    icon = Image.open(icon_path)
                except Exception:
                    # 如果ICO文件无法打开，使用默认图标
                    icon = Image.new('RGB', (64, 64), color="#4a90e2")
            else:
                # 如果文件不存在，使用默认图标
                icon = Image.new('RGB', (64, 64), color="#4a90e2")
            
            # 创建菜单
            menu = (item('显示窗口', self.show_window), item('退出程序', self.quit_program))
            
            # 创建系统托盘图标
            self.tray_icon = pystray.Icon("mouse_clicker", icon, "鼠标连点器", menu)
            
            # 启动系统托盘线程
            def run_tray_icon():
                try:
                    self.tray_icon.run()
                except Exception as e:
                    print(f"系统托盘错误: {e}")
            
            threading.Thread(target=run_tray_icon, daemon=True).start()
            
        except Exception as e:
            print(f"设置系统托盘时发生错误: {e}")
            pass
    
    def set_hotkey(self):
        """设置热键"""
        self.is_setting_hotkey = True
        self.is_setting_mouse_hotkey = True
        self.hotkey_label.config(text="等待按键...", foreground="#e74c3c")
        self.set_hotkey_button.config(text="取消设置", command=self.cancel_set_hotkey)
        
    def cancel_set_hotkey(self):
        """取消设置热键"""
        self.is_setting_hotkey = False
        self.is_setting_mouse_hotkey = False
        self.hotkey_label.config(text=self.hotkey_name, foreground="#4a90e2")
        self.set_hotkey_button.config(text="设置热键", command=self.set_hotkey)
    
    def update_hotkey_ui(self):
        """更新热键相关的UI元素"""
        self.hotkey_label.config(text=self.hotkey_name, foreground="#4a90e2")
        self.toggle_button.config(text=f"按{self.hotkey_name}键开始/停止")
        self.set_hotkey_button.config(text="设置热键", command=self.set_hotkey)
        self.is_setting_hotkey = False
        self.is_setting_mouse_hotkey = False
    
    def toggle_click_type(self):
        """切换点击类型（左键/右键）"""
        current_type = self.click_type.get()
        new_type = "right" if current_type == "left" else "left"
        self.click_type.set(new_type)
        
    def setup_global_key_listener(self):
        """设置全局键盘和鼠标监听"""
        def on_key_press(key):
            """键盘按下事件"""
            if self.is_setting_hotkey:
                # 设置新热键
                self.hotkey = key
                self.hotkey_type = "keyboard"
                # 转换键名格式
                try:
                    self.hotkey_name = key.char.upper() if hasattr(key, 'char') and key.char else str(key).replace('Key.', '').upper()
                except:
                    self.hotkey_name = str(key).replace('Key.', '').upper()
                self.update_hotkey_ui()
            elif self.hotkey_type == "keyboard" and key == self.hotkey:
                self.toggle_clicking()
            elif key == Key.alt_l:
                self.toggle_click_type()
        
        def on_mouse_press(x, y, button, pressed):
            """鼠标按下事件"""
            if pressed and self.is_setting_mouse_hotkey:
                # 设置新的鼠标热键
                self.hotkey = button
                self.hotkey_type = "mouse"
                # 转换键名格式
                if button == Button.left:
                    self.hotkey_name = "鼠标左键"
                elif button == Button.right:
                    self.hotkey_name = "鼠标右键"
                elif button == Button.middle:
                    self.hotkey_name = "鼠标中键"
                else:
                    self.hotkey_name = str(button).replace('Button.', '')
                self.update_hotkey_ui()
            elif pressed and self.hotkey_type == "mouse" and button == self.hotkey:
                self.toggle_clicking()
        
        # 启动全局键盘监听线程
        threading.Thread(target=lambda: Listener(on_press=on_key_press).start(), daemon=True).start()
        
        # 启动全局鼠标监听线程
        threading.Thread(target=lambda: MouseListener(on_click=on_mouse_press).start(), daemon=True).start()
    
    def toggle_clicking(self):
        """切换点击状态"""
        self.stop_clicking() if self.is_running else self.start_clicking()
    
    def start_clicking(self):
        """开始点击"""
        if self.is_running:
            return
        self.is_running = True
        self.status_label.config(text="状态: 运行中", foreground="green")
        self.click_thread = threading.Thread(target=self.click_loop, daemon=True)
        self.click_thread.start()
    
    def click_loop(self):
        """点击循环，使用win32api实现更高的点击速度"""
        try:
            while self.is_running:
                # 获取当前设置的点击速度
                current_clicks_per_second = self.clicks_per_second
                
                # 确定使用的点击方法
                if self.click_type.get() == "left":
                    click_event = win32con.MOUSEEVENTF_LEFTDOWN | win32con.MOUSEEVENTF_LEFTUP
                else:
                    click_event = win32con.MOUSEEVENTF_RIGHTDOWN | win32con.MOUSEEVENTF_RIGHTUP
                
                # 如果速度较低，使用单点击模式
                if current_clicks_per_second <= 500:
                    interval = 1.0 / current_clicks_per_second
                    start_time = time.perf_counter()
                    
                    # 使用win32api执行点击
                    win32api.mouse_event(click_event, 0, 0, 0, 0)
                    
                    # 计算等待时间
                    click_duration = time.perf_counter() - start_time
                    sleep_time = interval - click_duration
                    if sleep_time > 0:
                        time.sleep(sleep_time)
                # 如果速度较高，使用批量点击模式
                else:
                    # 每次处理500个点击，减少循环开销
                    batch_size = 500
                    batch_interval = batch_size / current_clicks_per_second
                    batch_start_time = time.perf_counter()
                    
                    for _ in range(batch_size):
                        if not self.is_running:
                            break
                        # 使用win32api执行点击
                        win32api.mouse_event(click_event, 0, 0, 0, 0)
                    
                    # 计算批量处理耗时
                    batch_duration = time.perf_counter() - batch_start_time
                    sleep_time = batch_interval - batch_duration
                    if sleep_time > 0:
                        time.sleep(sleep_time)
        except Exception as e:
            print(f"点击循环错误: {e}")
            self.is_running = False
            self.update_ui_status()
    
    def stop_clicking(self):
        """停止点击"""
        self.is_running = False
        self.update_ui_status()
    
    def setup_styles(self):
        """设置ttk样式"""
        style = ttk.Style()
        for widget in ["TFrame", "TLabel", "TButton", "TEntry", "TScale", "TRadiobutton"]:
            style.configure(widget, background=self.bg_color, foreground="black")
        style.configure("TButton", padding=5)
        style.map("TButton", background=[('active', '#4a90e2')], foreground=[('active', 'white')])
    
    def update_ui_status(self):
        """更新UI状态"""
        if self.is_running:
            self.status_label.config(text="状态: 运行中", foreground="#2ecc71")
        else:
            self.status_label.config(text="状态: 已停止", foreground="#e74c3c")
    
    def on_close(self):
        """窗口关闭事件"""
        # 如果已经设置了偏好，直接执行
        if self.close_preference == "minimize":
            self.on_minimize()
            return
        elif self.close_preference == "close":
            self.stop_clicking()
            self.quit_program()
            return
        
        # 否则显示询问对话框
        self.show_close_dialog()
    
    def show_close_dialog(self):
        """显示关闭询问对话框"""
        # 创建对话框
        dialog = tk.Toplevel(self.root)
        dialog.title("关闭确认")
        dialog.geometry("420x220")  # 增加高度以确保内容完整显示
        dialog.resizable(False, False)
        dialog.configure(bg="#87CEEB")  # 设置背景为天蓝色
        
        # 窗口居中
        dialog.update_idletasks()
        width, height = dialog.winfo_width(), dialog.winfo_height()
        x = (dialog.winfo_screenwidth() - width) // 2
        y = (dialog.winfo_screenheight() - height) // 2
        dialog.geometry(f'{width}x{height}+{x}+{y}')
        
        # 设置窗口图标
        try:
            dialog.iconbitmap('D:\\FMC\\FMC.ico')
        except:
            pass
        
        # 创建消息标签
        message_label = ttk.Label(dialog, text="您想要关闭程序还是最小化到系统托盘？", font=('Microsoft YaHei', 12))
        message_label.pack(pady=10)
        
        # 创建选项框架
        option_frame = ttk.Frame(dialog)
        option_frame.pack(pady=10, padx=20, fill="x")
        
        # 创建单选按钮变量
        self.close_option = tk.StringVar(value="minimize")
        
        # 创建确定按钮
        confirm_button = ttk.Button(option_frame, text="确定", command=lambda: self.handle_close_choice(dialog), width=15)  # 增加按钮宽度
        confirm_button.pack(anchor="center", pady=0)  # 完全移除按钮的外边距
        
        # 创建单选按钮
        minimize_radio = ttk.Radiobutton(option_frame, text="最小化到系统托盘", variable=self.close_option, value="minimize")
        minimize_radio.pack(anchor="w", pady=5)
        
        close_radio = ttk.Radiobutton(option_frame, text="关闭程序", variable=self.close_option, value="close")
        close_radio.pack(anchor="w", pady=5)
        
        # 创建保留选择复选框
        self.remember_choice = tk.BooleanVar(value=False)
        remember_check = ttk.Checkbutton(option_frame, text="保留选择", variable=self.remember_choice)
        remember_check.pack(anchor="w", pady=1)  # 进一步减少复选框的下外边距
        
        # 确保对话框获得焦点
        dialog.transient(self.root)
        dialog.grab_set()
        self.root.wait_window(dialog)
    
    def handle_close_choice(self, dialog):
        """处理关闭选择"""
        choice = self.close_option.get()
        remember = self.remember_choice.get()
        
        # 保存选择（如果需要）
        if remember:
            self.close_preference = choice
        
        # 关闭对话框
        dialog.destroy()
        
        # 执行选择的操作
        if choice == "minimize":
            self.on_minimize()
        else:
            self.stop_clicking()
            self.quit_program()
    
    def on_minimize(self):
        """窗口最小化"""
        self.root.withdraw()
    
    def show_window(self):
        """显示窗口"""
        self.root.deiconify()
        self.root.lift()
    
    def quit_program(self):
        """退出程序"""
        self.stop_clicking()
        if hasattr(self, 'tray_icon'):
            self.tray_icon.stop()
        self.root.destroy()
    
    def show_clicker_info(self):
        """显示连点器信息，打开指定网页"""
        webbrowser.open("https://furina-ls.github.io/")
    
    def check_for_updates(self):
        """检查是否有更新"""
        update_url = "https://furina-ls.github.io/FMC.zip"
        # 使用当前脚本所在目录替代硬编码路径
        local_fmc_path = os.path.dirname(os.path.abspath(__file__))
        try:
            # 检查本地FMC目录是否存在
            if not os.path.exists(local_fmc_path):
                return
            
            # 检查远程更新包是否存在
            response = requests.head(update_url, allow_redirects=True)
            if response.status_code == 200:
                # 比较本地和远程版本
                if self.compare_versions(local_fmc_path, update_url):
                    # 在UI线程中显示更新提示
                    self.root.after(0, lambda: self.show_update_prompt(update_url))
        except Exception as e:
            print(f"检查更新错误: {e}")
    
    def get_local_zip_path(self):
        """获取本地保存FMC.zip文件的路径"""
        local_fmc_path = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(local_fmc_path, "FMC.zip")
    
    def compare_versions(self, local_path, remote_url):
        """比较本地和远程版本（直接比较解压后的文件内容）"""
        temp_dir = None
        try:
            # 创建临时目录用于下载和提取远程文件
            temp_dir = os.path.join(os.getenv("TEMP"), "FMC_update_check")
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
            
            # 下载远程压缩包
            remote_zip_path = os.path.join(temp_dir, "FMC.zip")
            print(f"开始下载远程更新包: {remote_url}")
            response = requests.get(remote_url, allow_redirects=True)
            if response.status_code != 200:
                print(f"无法访问远程更新包，状态码: {response.status_code}")
                return False  # 远程文件不可访问，不需要更新
            
            with open(remote_zip_path, 'wb') as f:
                f.write(response.content)
            
            print(f"成功下载远程更新包，大小: {os.path.getsize(remote_zip_path)} 字节")
            
            # 获取本地mouse_clicker.py的内容（直接使用当前脚本路径）
            local_file_path = os.path.abspath(__file__)
            if not os.path.exists(local_file_path):
                print("本地mouse_clicker.py文件不存在")
                return True  # 本地文件不存在，需要更新
            
            # 读取本地文件内容
            with open(local_file_path, 'r', encoding='utf-8') as f:
                local_content = f.read()
            
            print(f"本地文件内容长度: {len(local_content)}")
            
            # 解压远程压缩包
            extract_path = os.path.join(temp_dir, "extracted")
            if not os.path.exists(extract_path):
                os.makedirs(extract_path)
            
            with zipfile.ZipFile(remote_zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
            
            print("成功解压远程更新包")
            
            # 查看解压后的目录结构
            print("解压后的目录结构:")
            for root, dirs, files in os.walk(extract_path):
                level = root.replace(extract_path, '').count(os.sep)
                indent = ' ' * 2 * level
                print(f"{indent}{os.path.basename(root)}/")
                subindent = ' ' * 2 * (level + 1)
                for file in files:
                    print(f"{subindent}{file}")
            
            # 读取远程mouse_clicker.py的内容
            # 根据实际压缩包结构，尝试多种可能的路径
            possible_paths = [
                os.path.join(extract_path, "FMC", "FMC", "FMC", "mouse_clicker.py"),
                os.path.join(extract_path, "FMC", "FMC", "mouse_clicker.py"),
                os.path.join(extract_path, "FMC", "mouse_clicker.py"),
                os.path.join(extract_path, "mouse_clicker.py")
            ]
            
            remote_file_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    remote_file_path = path
                    print(f"找到远程文件: {path}")
                    break
            
            if not remote_file_path:
                print(f"无法在更新包中找到mouse_clicker.py文件，尝试的路径: {possible_paths}")
                return False  # 远程文件中没有找到mouse_clicker.py
            
            with open(remote_file_path, 'r', encoding='utf-8') as f:
                remote_content = f.read()
            
            print(f"远程文件内容长度: {len(remote_content)}")
            
            # 直接比较文件内容
            return local_content != remote_content
        except Exception as e:
            print(f"版本比较错误: {e}")
            import traceback
            traceback.print_exc()
            return False  # 出错时默认不需要更新
        finally:
            # 清理临时文件
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                    print(f"成功清理临时目录: {temp_dir}")
                except Exception as cleanup_err:
                    print(f"清理临时目录时出错: {cleanup_err}")
    
    def show_update_prompt(self, update_url):
        """显示更新提示"""
        # 创建自定义对话框
        dialog = tk.Toplevel(self.root)
        dialog.title("更新提示")
        dialog.geometry("300x150")
        dialog.resizable(False, False)
        dialog.configure(bg="#87CEEB")  # 设置背景为天蓝色
        
        # 窗口居中
        dialog.update_idletasks()
        width, height = dialog.winfo_width(), dialog.winfo_height()
        x = (dialog.winfo_screenwidth() - width) // 2
        y = (dialog.winfo_screenheight() - height) // 2
        dialog.geometry(f'{width}x{height}+{x}+{y}')
        
        # 设置窗口图标
        try:
            dialog.iconbitmap('D:\\FMC\\FMC.ico')
        except:
            pass
        
        # 创建消息标签
        message_label = ttk.Label(dialog, text="检测到新版本，是否更新？", font=('Microsoft YaHei', 12))
        message_label.pack(pady=20)
        
        # 创建按钮框架
        button_frame = ttk.Frame(dialog)
        button_frame.pack(pady=10)
        
        # 创建是/否按钮
        yes_button = ttk.Button(button_frame, text="冲！", command=lambda: self.handle_update_choice(dialog, update_url, True), width=10)
        yes_button.pack(side="left", padx=10)
        
        no_button = ttk.Button(button_frame, text="先等等...", command=lambda: self.handle_update_choice(dialog, update_url, False), width=10)
        no_button.pack(side="left", padx=10)
        
        # 确保对话框获得焦点
        dialog.transient(self.root)
        dialog.grab_set()
        self.root.wait_window(dialog)
    
    def handle_update_choice(self, dialog, update_url, choice):
        """处理更新选择"""
        dialog.destroy()
        if choice:
            # 在后台线程中执行更新操作
            threading.Thread(target=self.download_and_update, args=(update_url,), daemon=True).start()
    
    def download_and_update(self, update_url):
        """下载并更新程序"""
        temp_dir = None
        try:
            # 创建临时目录
            temp_dir = os.path.join(os.getenv("TEMP"), "FMC_update")
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
            
            # 关闭除当前实例外的所有连点器程序
            print("正在关闭其他连点器程序...")
            self.close_other_instances()
            
            # 下载更新包
            zip_path = os.path.join(temp_dir, "FMC.zip")
            self.download_update(update_url, zip_path)
            
            # 将下载的FMC.zip保存到本地，用于下次更新检查
            local_zip_path = self.get_local_zip_path()
            try:
                shutil.copy2(zip_path, local_zip_path)
                print(f"成功保存FMC.zip到本地: {local_zip_path}")
            except Exception as e:
                print(f"保存FMC.zip到本地失败: {e}")
            
            # 解压更新包
            extract_path = os.path.join(temp_dir, "extracted")
            self.extract_update(zip_path, extract_path)
            
            # 获取当前脚本的文件名
            current_script = os.path.basename(__file__)
            
            # 替换本地文件（跳过正在运行的脚本文件）
            local_fmc_path = os.path.dirname(os.path.abspath(__file__))
            self.replace_files(extract_path, local_fmc_path, skip_file=current_script)
            
            # 重启应用程序
            self.restart_application(extract_path=extract_path, current_script=current_script)
        except Exception as e:
            print(f"更新错误: {e}")
            # 在UI线程中显示错误信息
            self.root.after(0, lambda: messagebox.showerror("更新失败", f"更新过程中发生错误: {e}"))
        finally:
            # 清理临时目录
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except:
                    pass
    
    def download_update(self, url, save_path):
        """下载更新包"""
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
    
    def extract_update(self, zip_path, extract_path):
        """解压更新包"""
        if not os.path.exists(extract_path):
            os.makedirs(extract_path)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
    
    def replace_files(self, source_path, target_path, skip_file=None):
        """替换本地文件，处理文件锁定问题"""
        # 确保源路径是FMC目录
        source_fmc_path = os.path.join(source_path, "FMC")
        if not os.path.exists(source_fmc_path):
            source_fmc_path = source_path  # 如果没有FMC子目录，直接使用源路径
        
        # 遍历源目录中的所有文件和子目录
        for item in os.listdir(source_fmc_path):
            # 跳过指定的文件（通常是正在运行的脚本文件）
            if skip_file and item == skip_file:
                continue
                
            source_item = os.path.join(source_fmc_path, item)
            target_item = os.path.join(target_path, item)
            
            try:
                if os.path.isdir(source_item):
                    # 如果是目录，递归替换
                    if os.path.exists(target_item):
                        shutil.rmtree(target_item)
                    shutil.copytree(source_item, target_item)
                else:
                    # 如果是文件，直接替换
                    if os.path.exists(target_item):
                        os.remove(target_item)
                    shutil.copy2(source_item, target_item)
                    print(f"成功替换文件: {item}")
            except (OSError, PermissionError) as e:
                # 记录错误但继续处理其他文件
                print(f"替换文件时出错: {e}")
                # 对于.ico文件，尝试重命名后复制
                if item.lower().endswith('.ico'):
                    try:
                        # 重命名旧文件
                        backup_path = target_item + '.bak'
                        os.rename(target_item, backup_path)
                        # 复制新文件
                        shutil.copy2(source_item, target_item)
                        # 删除备份文件
                        os.remove(backup_path)
                        print(f"成功替换图标文件: {item}")
                    except Exception as e2:
                        # 如果重命名也失败，跳过.ico文件
                        print(f"跳过图标文件 {item}，因为它正在被使用: {e2}")
    
    def close_other_instances(self):
        """关闭除当前实例外的所有连点器程序进程"""
        current_pid = os.getpid()
        current_script = os.path.abspath(__file__)
        script_name = os.path.basename(current_script)
        
        try:
            # 使用WMIC命令获取所有Python进程的PID和命令行
            command = f"wmic process where \"name='python.exe' OR name='pythonw.exe'\" get ProcessId, CommandLine"
            result = subprocess.run(command, capture_output=True, text=True, shell=True)
            
            if result.returncode == 0:
                # 解析WMIC输出
                lines = result.stdout.strip().split('\n')
                # 跳过标题行
                for line in lines[1:]:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # 分割PID和命令行
                    parts = line.split(None, 1)
                    if len(parts) < 2:
                        continue
                    
                    pid = int(parts[0])
                    cmdline = parts[1]
                    
                    # 跳过当前进程
                    if pid == current_pid:
                        continue
                    
                    # 检查命令行是否包含连点器程序名称
                    if script_name in cmdline:
                        print(f"关闭其他连点器进程: PID={pid}")
                        try:
                            # 使用WMIC命令终止进程
                            terminate_cmd = f'wmic process where ProcessId={pid} delete'
                            subprocess.run(terminate_cmd, capture_output=True, text=True, shell=True)
                            print(f"成功终止进程: PID={pid}")
                        except Exception as e:
                            print(f"终止进程时出错: {e}")
        except Exception as e:
            print(f"关闭其他实例时出错: {e}")
    
    def restart_application(self, extract_path=None, current_script=None):
        """重启应用程序"""
        try:
            # 停止点击操作
            self.stop_clicking()
            
            # 获取当前Python解释器和脚本路径
            python_exe = sys.executable
            script_path = os.path.abspath(__file__)
            
            if extract_path and current_script:
                # 确保源路径是FMC目录
                source_fmc_path = os.path.join(extract_path, "FMC")
                if not os.path.exists(source_fmc_path):
                    source_fmc_path = extract_path
                    
                # 获取新脚本的路径
                new_script_path = os.path.join(source_fmc_path, current_script)
                
                # 使用批处理文件来替换并重启程序
                batch_content = f'''
@echo off
REM 等待当前程序退出
ping 127.0.0.1 -n 2 > nul
REM 替换程序文件
copy "{new_script_path}" "{script_path}" /Y
REM 启动新程序
start "" "{python_exe}" "{script_path}"
'''
                batch_path = os.path.join(os.getenv("TEMP"), "FMC_update_restart.bat")
                with open(batch_path, 'w') as f:
                    f.write(batch_content)
                
                # 执行批处理文件
                import subprocess
                subprocess.Popen(batch_path, creationflags=subprocess.CREATE_NEW_CONSOLE)
            else:
                # 常规重启
                import subprocess
                subprocess.Popen([python_exe, script_path], creationflags=subprocess.CREATE_NEW_CONSOLE)
                
                # 确保新实例有足够时间启动
                time.sleep(1)
            
            # 再退出当前程序
            self.quit_program()
        except Exception as e:
            print(f"重启错误: {e}")
            # 显示重启失败的提示
            self.root.after(0, lambda: messagebox.showerror("重启失败", f"重启过程中发生错误: {e}"))
    
    def run(self):
        """运行程序"""
        self.root.mainloop()

# 单实例检测
def check_single_instance():
    """检查是否已有实例运行"""
    # 获取当前脚本所在目录的绝对路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    lock_file = os.path.join(script_dir, "mouse_clicker.lock")
    
    # 对于Windows系统，更可靠的锁文件残留检查
    if os.name == 'nt' and os.path.exists(lock_file):
        # 首先尝试简单的删除，如果成功说明文件没有被锁定
        try:
            os.remove(lock_file)
        except OSError:
            # 删除失败，可能被锁定
            try:
                # 尝试以独占模式打开文件
                lock_file_handle = os.open(lock_file, os.O_CREAT | os.O_EXCL | os.O_RDWR)
                os.close(lock_file_handle)
                # 如果成功打开，说明没有进程在使用它，删除旧的锁文件
                os.remove(lock_file)
            except OSError:
                import msvcrt
                lock_file_handle = None
                try:
                    # 尝试打开文件并锁定
                    lock_file_handle = open(lock_file, 'r+')
                    msvcrt.locking(lock_file_handle, msvcrt.LK_NBLCK, 1)
                    # 成功锁定，说明没有进程在使用
                    msvcrt.locking(lock_file_handle, msvcrt.LK_UNLCK, 1)
                    lock_file_handle.close()
                    os.remove(lock_file)
                except:
                    # 无法锁定或其他错误，说明有进程在使用
                    if lock_file_handle:
                        try:
                            lock_file_handle.close()
                        except:
                            pass
                    return None, False
    
    # 尝试创建新的锁文件
    try:
        if os.name == 'nt':  # Windows系统
            import msvcrt
            # 使用os.O_CREAT | os.O_EXCL | os.O_RDWR标志创建锁文件
            lock_file_handle = os.open(lock_file, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            # 使用msvcrt.locking进行文件锁定
            msvcrt.locking(lock_file_handle, msvcrt.LK_NBLCK, 1)
            return lock_file_handle, True
        else:  # 其他系统
            import fcntl
            lock_file_handle = open(lock_file, 'w')
            fcntl.flock(lock_file_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return lock_file_handle, True
    except FileExistsError:
        # 文件已存在，说明在检查和创建之间有其他进程创建了锁文件
        return None, False
    except:
        # 其他错误
        return None, False

# 释放实例锁
def release_instance_lock(lock_file_handle):
    """释放实例锁"""
    try:
        if lock_file_handle:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            lock_file = os.path.join(script_dir, "mouse_clicker.lock")
            
            if os.name == 'nt':  # Windows系统
                import msvcrt
                try:
                    msvcrt.locking(lock_file_handle, msvcrt.LK_UNLCK, 1)
                except:
                    pass  # 忽略解锁错误
                os.close(lock_file_handle)
            else:  # 其他系统
                import fcntl
                try:
                    fcntl.flock(lock_file_handle, fcntl.LOCK_UN)
                except:
                    pass  # 忽略解锁错误
                lock_file_handle.close()
            
            # 尝试删除锁文件
            if os.path.exists(lock_file):
                try:
                    os.remove(lock_file)
                except:
                    pass  # 忽略删除错误
    except:
        pass

if __name__ == "__main__":
    # 检查是否已有实例运行
    lock_file_handle, is_single_instance = check_single_instance()
    
    if not is_single_instance:
        # 已有实例运行，显示提示
        # 创建一个简单的根窗口用于显示消息
        temp_root = tk.Tk()
        temp_root.withdraw()  # 隐藏窗口
        
        # 询问用户是否多开
        result = messagebox.askyesno("多开提示", "检测到已有连点器实例正在运行。\n您是否要继续启动新的实例？")
        
        if not result:
            # 用户选择不继续，退出程序
            temp_root.destroy()  # 确保销毁临时窗口
            sys.exit(0)
        
        # 用户选择继续，销毁临时窗口
        temp_root.destroy()
    
    try:
        # 启动程序
        app = MouseClicker()
        app.run()
    except KeyboardInterrupt:
        # 处理键盘中断
        pass
    except Exception as e:
        # 处理其他异常
        print(f"程序异常退出: {e}")
    finally:
        # 确保释放实例锁
        release_instance_lock(lock_file_handle)