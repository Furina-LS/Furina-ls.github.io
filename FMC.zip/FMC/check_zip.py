import requests
import zipfile
import os
import tempfile

url = 'https://furina-ls.github.io/FMC.zip'

try:
    # 下载压缩包
    print(f'正在下载压缩包: {url}')
    response = requests.get(url)
    response.raise_for_status()
    
    # 保存到临时文件
    with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as f:
        f.write(response.content)
        zip_path = f.name
    
    try:
        # 查看压缩包内容
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            print('压缩包内容:')
            for file in zip_ref.namelist():
                print(f'  {file}')
    finally:
        # 清理临时文件
        os.unlink(zip_path)
        print(f'已清理临时文件: {zip_path}')
        
except Exception as e:
    print(f'发生错误: {e}')
